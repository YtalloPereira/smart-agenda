import json
from intents.agendar_compromisso_intent import handle_agendar_compromisso_intent
from intents.cancelar_compromisso_intent import handle_cancelar_compromisso_intent

def lambda_handler(event, context):
    # Extrai a intenção e os slots do evento
    intent = event['sessionState']['intent']['name']
    
    if intent == 'AgendarCompromissoIntent':
        response = handle_agendar_compromisso_intent(event)
    elif intent == 'CancelarCompromissoIntent':
        response = handle_cancelar_compromisso_intent(event)
    else:
        # Caso a intenção não seja reconhecida, configura a fallback intent
        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": "FallbackIntent",  # Nome da sua fallback intent
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": "Desculpe, não entendi a sua solicitação. Pode me dizer novamente?"
                }
            ]
        }
    
    return response



