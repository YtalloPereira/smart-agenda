import urllib3
import json
import boto3
import hashlib
from datetime import datetime, timedelta

# Inicializar clientes DynamoDB e Lambda
http = urllib3.PoolManager()
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('agendamentos')

# Limitar os tipos de compromisso a no máximo 5 itens
compromisso_types = [
    'Consulta Médica', 'Consulta ao Dentista', 'Academia', 'Jogo de Futebol', 'Encontro Pessoal'
]

def convert_to_24_hour_format(time_str):
    time_str = time_str.lower().strip()
    try:
        if 'da manhã' in time_str or 'am' in time_str:
            time_str = time_str.replace('da manhã', '').replace('am', '').strip()
            return datetime.strptime(time_str, '%I').strftime('%H:00')
        elif 'da noite' in time_str or 'pm' in time_str:
            time_str = time_str.replace('da noite', '').replace('pm', '').strip()
            return datetime.strptime(time_str, '%I').strftime('%H:00')
        else:
            return datetime.strptime(time_str, '%H:%M').strftime('%H:%M')
    except ValueError:
        return time_str

def convert_date_to_brazilian_format(date_str):
    return datetime.strptime(date_str, '%Y-%m-%d').strftime('%d/%m/%Y')

def generate_id(data, hora, tipoCompromisso):
    id_str = f"{data}_{hora}_{tipoCompromisso}"
    return hashlib.md5(id_str.encode()).hexdigest()

def save_compromisso_to_dynamodb(compromisso):
    table.put_item(Item=compromisso)
    
def generate_audio(message):
    api_url = 'https://9xmnluesl2.execute-api.us-east-1.amazonaws.com/v1/tts'  
    payload = json.dumps({'phrase': message})
    headers = {'Content-Type': 'application/json'}

    response = http.request('POST', api_url, body=payload, headers=headers)
    response_data = json.loads(response.data.decode('utf-8'))

    if response.status == 200:
        return response_data.get('url_to_audio')
    else:
        return "Erro ao converter o texto para áudio"

def validate_agendamento(slots):
    if not slots['tipoCompromisso']:
        return {
            'isValid': False,
            'invalidSlot': 'tipoCompromisso'
        }

    tipoCompromisso_value = slots['tipoCompromisso']['value']['originalValue'].strip().lower()
    valid_compromisso_types = [tipo.lower() for tipo in compromisso_types]

    if tipoCompromisso_value not in valid_compromisso_types:
        return {
            'isValid': False,
            'invalidSlot': 'tipoCompromisso',
            'message': 'Por favor, selecione um tipo de compromisso válido: {}.'.format(", ".join(compromisso_types[:5])) # Limitado a 5 opções
        }

    if not slots.get('data') or not slots['data'].get('value'):
        return {
            'isValid': False,
            'invalidSlot': 'data'
        }

    if not slots.get('horario') or not slots['horario'].get('value'):
        return {
            'isValid': False,
            'invalidSlot': 'horario'
        }

    return {'isValid': True}
    
def handle_agendar_compromisso_intent(event):
    slots = event['sessionState']['intent']['slots']
    intent = event['sessionState']['intent']['name']

    agendamento_validation_result = validate_agendamento(slots)

    if event['invocationSource'] == 'DialogCodeHook':
        if not agendamento_validation_result['isValid']:
            response_message = ''
            response_card_buttons = []

            if agendamento_validation_result['invalidSlot'] == "tipoCompromisso":
                response_message = 'Selecione um tipo de compromisso.'
                response_card_buttons = [{'text': tipo, 'value': tipo} for tipo in compromisso_types]

                response = {
                    "sessionState": {
                        "dialogAction": {
                            "slotToElicit": agendamento_validation_result['invalidSlot'],
                            "type": "ElicitSlot"
                        },
                        "intent": {
                            "name": intent,
                            "slots": slots
                        }
                    },
                    "messages": [
                        {
                            "contentType": "ImageResponseCard",
                            "content": 'Selecione o tipo de compromisso.',
                            "imageResponseCard": {
                                "title": "Tipo de Compromisso",
                                "subtitle": "Escolha um tipo de compromisso:",
                                "buttons": response_card_buttons
                            }
                        }
                    ]
                }
            elif agendamento_validation_result['invalidSlot'] == "data":
                response_message = 'Selecione uma data válida.'

                response = {
                    "sessionState": {
                        "dialogAction": {
                            "slotToElicit": 'data',
                            "type": "ElicitSlot"
                        },
                        "intent": {
                            "name": intent,
                            "slots": slots
                        }
                    },
                    "messages": [
                        {
                            "contentType": "PlainText",
                            "content": response_message
                        }
                    ]
                }
            elif agendamento_validation_result['invalidSlot'] == "horario":
                response_message = 'Selecione um horário válido.'

                response = {
                    "sessionState": {
                        "dialogAction": {
                            "slotToElicit": 'horario',
                            "type": "ElicitSlot"
                        },
                        "intent": {
                            "name": intent,
                            "slots": slots
                        }
                    },
                    "messages": [
                        {
                            "contentType": "PlainText",
                            "content": response_message
                        }
                    ]
                }
        else:
            response = {
                "sessionState": {
                    "dialogAction": {
                        "type": "Delegate"
                    },
                    "intent": {
                        'name': intent,
                        'slots': slots
                    }
                }
            }

    if event['invocationSource'] == 'FulfillmentCodeHook':
        data = slots['data']['value']['interpretedValue']
        hora = slots['horario']['value']['interpretedValue']
        tipoCompromisso = slots['tipoCompromisso']['value']['originalValue'].strip().lower()

        if data.lower() == 'amanha':
            data = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')

        hora = convert_to_24_hour_format(hora)
        data_brazilian_format = convert_date_to_brazilian_format(data)

        id = generate_id(data_brazilian_format, hora, tipoCompromisso)

        compromisso = {
            'id': id,
            'data': data_brazilian_format,
            'hora': hora,
            'tipoCompromisso': tipoCompromisso
        }
        save_compromisso_to_dynamodb(compromisso)

        audio_message = f"Seu compromisso {tipoCompromisso} foi agendado com sucesso para {data_brazilian_format} às {hora} horas."
        audio_url = generate_audio(audio_message)

        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": intent,
                    "slots": slots,
                    "state": "Fulfilled"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": audio_message
                }
            ]
        }

        if audio_url:
            response['messages'].append({
                "contentType": "PlainText",
                "content": f"Aqui está o áudio do seu compromisso: {audio_url}"
            })

    return response