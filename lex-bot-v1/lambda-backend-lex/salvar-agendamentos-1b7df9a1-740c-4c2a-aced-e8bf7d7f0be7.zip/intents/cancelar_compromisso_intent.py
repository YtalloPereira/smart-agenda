import json
import boto3

# Inicializar o cliente do DynamoDB
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('agendamentos')

def handle_cancelar_compromisso_intent(event):
    print(f"Evento recebido: {json.dumps(event)}")  # Adicione este log para depuração
    try:
        slots = event.get('sessionState', {}).get('intent', {}).get('slots', {})
        compromisso_id_slot = slots.get('compromissoId', {})
        compromisso_id_value = compromisso_id_slot.get('value', {})
        compromisso_id = compromisso_id_value.get('originalValue', '').strip()
        
        if not compromisso_id:
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "Close"
                    },
                    "intent": {
                        "name": "CancelarCompromissoIntent",
                        "state": "Failed"
                    }
                },
                "messages": [
                    {
                        "contentType": "PlainText",
                        "content": "Por favor, forneça o ID do compromisso que deseja cancelar."
                    }
                ]
            }

        # Excluir o compromisso da tabela
        response = table.delete_item(
            Key={'id': compromisso_id}
        )

        # Verificar se o item foi excluído
        if response.get('ResponseMetadata', {}).get('HTTPStatusCode') == 200:
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "Close"
                    },
                    "intent": {
                        "name": "CancelarCompromissoIntent",
                        "state": "Fulfilled"
                    }
                },
                "messages": [
                    {
                        "contentType": "PlainText",
                        "content": f"Compromisso com ID {compromisso_id} foi cancelado com sucesso."
                    }
                ]
            }
        else:
            return {
                "sessionState": {
                    "dialogAction": {
                        "type": "Close"
                    },
                    "intent": {
                        "name": "CancelarCompromissoIntent",
                        "state": "Failed"
                    }
                },
                "messages": [
                    {
                        "contentType": "PlainText",
                        "content": "Não foi possível cancelar o compromisso. Por favor, tente novamente mais tarde."
                    }
                ]
            }

    except Exception as e:
        # Log de erro e resposta padrão
        print(f"Erro: {e}")
        return {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    "name": "CancelarCompromissoIntent",
                    "state": "Failed"
                }
            },
            "messages": [
                {
                    "contentType": "PlainText",
                    "content": "Desculpe, ocorreu um erro ao tentar cancelar o compromisso. Por favor, tente novamente mais tarde."
                }
            ]
        }
